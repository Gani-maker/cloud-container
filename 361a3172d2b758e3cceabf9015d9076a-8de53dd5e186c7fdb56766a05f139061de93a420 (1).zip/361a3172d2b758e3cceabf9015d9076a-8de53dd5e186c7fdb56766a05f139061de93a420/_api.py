{
  "$schema": "http://cyclonedx.org/schema/bom-1.4.schema.json",
  "bomFormat": "CycloneDX",
  "components": [
    {
      "bom-ref": "bom-ref:pip",
      "name": "pip",
      "type": "library"
    },
    {
      "bom-ref": "pkg:pypi/CacheControl@0.14.4",
      "name": "CacheControl",
      "purl": "pkg:pypi/CacheControl@0.14.4",
      "type": "library",
      "version": "0.14.4"
    },
    {
      "bom-ref": "pkg:pypi/certifi@2026.10.19",
      "name": "certifi",
      "purl": "pkg:pypi/certifi@2026.10.19",
      "type": "library",
      "version": "2026.10.19"
    },
    {
      "bom-ref": "pkg:pypi/distlib@0.4.2",
      "name": "distlib",
      "purl": "pkg:pypi/distlib@0.4.2",
      "type": "library",
      "version": "0.4.2"
    },
    {
      "bom-ref": "pkg:pypi/distro@1.9.0",
      "name": "distro",
      "purl": "pkg:pypi/distro@1.9.0",
      "type": "library",
      "version": "1.9.0"
    },
    {
      "bom-ref": "pkg:pypi/idna@3.18",
      "name": "idna",
      "purl": "pkg:pypi/idna@3.18",
      "type": "library",
      "version": "3.18"
    },
    {
      "bom-ref": "pkg:pypi/msgpack@1.1.2",
      "name": "msgpack",
      "purl": "pkg:pypi/msgpack@1.1.2",
      "type": "library",
      "version": "1.1.2"
    },
    {
      "bom-ref": "pkg:pypi/packaging@26.2",
      "name": "packaging",
      "purl": "pkg:pypi/packaging@26.2",
      "type": "library",
      "version": "26.2"
    },
    {
      "bom-ref": "pkg:pypi/platformdirs@4.10.0",
      "name": "platformdirs",
      "purl": "pkg:pypi/platformdirs@4.10.0",
      "type": "library",
      "version": "4.10.0"
    },
    {
      "bom-ref": "pkg:pypi/pygments@2.20.0",
      "name": "pygments",
      "purl": "pkg:pypi/pygments@2.20.0",
      "type": "library",
      "version": "2.20.0"
    },
    {
      "bom-ref": "pkg:pypi/pyproject-hooks@1.2.0",
      "name": "pyproject-hooks",
      "purl": "pkg:pypi/pyproject-hooks@1.2.0",
      "type": "library",
      "version": "1.2.0"
    },
    {
      "bom-ref": "pkg:pypi/requests@2.34.2",
      "name": "requests",
      "purl": "pkg:pypi/requests@2.34.2",
      "type": "library",
      "version": "2.34.2"
    },
    {
      "bom-ref": "pkg:pypi/resolvelib@1.2.1",
      "name": "resolvelib",
      "purl": "pkg:pypi/resolvelib@1.2.1",
      "type": "library",
      "version": "1.2.1"
    },
    {
      "bom-ref": "pkg:pypi/rich@14.2.0",
      "name": "rich",
      "purl": "pkg:pypi/rich@14.2.0",
      "type": "library",
      "version": "14.2.0"
    },
    {
      "bom-ref": "pkg:pypi/setuptools@70.3.0",
      "name": "setuptools",
      "purl": "pkg:pypi/setuptools@70.3.0",
      "type": "library",
      "version": "70.3.0"
    },
    {
      "bom-ref": "pkg:pypi/tomli@2.4.1",
      "name": "tomli",
      "purl": "pkg:pypi/tomli@2.4.1",
      "type": "library",
      "version": "2.4.1"
    },
    {
      "bom-ref": "pkg:pypi/tomli-w@1.2.0",
      "name": "tomli-w",
      "purl": "pkg:pypi/tomli-w@1.2.0",
      "type": "library",
      "version": "1.2.0"
    },
    {
      "bom-ref": "pkg:pypi/truststore@0.10.4",
      "name": "truststore",
      "purl": "pkg:pypi/truststore@0.10.4",
      "type": "library",
      "version": "0.10.4"
    },
    {
      "bom-ref": "pkg:pypi/urllib3@2.7.0",
      "name": "urllib3",
      "purl": "pkg:pypi/urllib3@2.7.0",
      "type": "library",
      "version": "2.7.0"
    }
  ],
  "dependencies": [
    {
      "dependsOn": [
        "pkg:pypi/CacheControl@0.14.4",
        "pkg:pypi/certifi@2026.10.19",
        "pkg:pypi/distlib@0.4.2",
        "pkg:pypi/distro@1.9.0",
        "pkg:pypi/idna@3.18",
        "pkg:pypi/msgpack@1.1.2",
        "pkg:pypi/packaging@26.2",
        "pkg:pypi/platformdirs@4.10.0",
        "pkg:pypi/pygments@2.20.0",
        "pkg:pypi/pyproject-hooks@1.2.0",
        "pkg:pypi/requests@2.34.2",
        "pkg:pypi/resolvelib@1.2.1",
        "pkg:pypi/rich@14.2.0",
        "pkg:pypi/setuptools@70.3.0",
        "pkg:pypi/tomli@2.4.1",
        "pkg:pypi/tomli-w@1.2.0",
        "pkg:pypi/truststore@0.10.4",
        "pkg:pypi/urllib3@2.7.0"
      ],
      "ref": "bom-ref:pip"
    },
    {
      "ref": "pkg:pypi/CacheControl@0.14.4"
    },
    {
      "ref": "pkg:pypi/certifi@2026.10.19"
    },
    {
      "ref": "pkg:pypi/distlib@0.4.2"
    },
    {
      "ref": "pkg:pypi/distro@1.9.0"
    },
    {
      "ref": "pkg:pypi/idna@3.18"
    },
    {
      "ref": "pkg:pypi/msgpack@1.1.2"
    },
    {
      "ref": "pkg:pypi/packaging@26.2"
    },
    {
      "ref": "pkg:pypi/platformdirs@4.10.0"
    },
    {
      "ref": "pkg:pypi/pygments@2.20.0"
    },
    {
      "ref": "pkg:pypi/pyproject-hooks@1.2.0"
    },
    {
      "ref": "pkg:pypi/requests@2.34.2"
    },
    {
      "ref": "pkg:pypi/resolvelib@1.2.1"
    },
    {
      "ref": "pkg:pypi/rich@14.2.0"
    },
    {
      "ref": "pkg:pypi/setuptools@70.3.0"
    },
    {
      "ref": "pkg:pypi/tomli@2.4.1"
    },
    {
      "ref": "pkg:pypi/tomli-w@1.2.0"
    },
    {
      "ref": "pkg:pypi/truststore@0.10.4"
    },
    {
      "ref": "pkg:pypi/urllib3@2.7.0"
    }
  ],
  "metadata": {
    "component": {
      "bom-ref": "bom-ref:pip",
      "name": "pip",
      "type": "library"
    },
    "tools": [
      {
        "name": "vendoring",
        "version": "1.4.0"
      }
    ]
  },
  "specVersion": "1.4",
  "version": 1
}
